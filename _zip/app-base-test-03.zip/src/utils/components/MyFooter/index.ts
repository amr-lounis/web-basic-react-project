import MyFooter from "./MyFooter";

export { MyFooter };
