export default function Footer() {
  return (
    <>
      <br/>---------------------------------------------<br/>
      Footer
      <line></line>
    </>
  );
}
