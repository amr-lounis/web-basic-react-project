import { toast } from "react-toastify";

//to make notifactio to any componentet
export const myNotify = (msg: String, type: "warn" | "success" | "error") => {
  if (type === "warn") toast.warn(msg);
  else if (type === "success") toast.success(msg);
  else if (type === "error") toast.error(msg);
};
// in main app add
// import { ToastContainer } from "react-toastify";
// import 'react-toastify/dist/ReactToastify.css';
// function App() {
//   return (
//     <>
//     <ToastContainer />