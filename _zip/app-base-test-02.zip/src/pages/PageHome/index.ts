import PageHome from "./PageHome";

export { PageHome };
