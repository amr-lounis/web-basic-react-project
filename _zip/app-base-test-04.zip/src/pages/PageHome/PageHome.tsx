import { myNotify } from "@/utils/components/MyNotify";
import { Captcha } from "@U/components/MyCaptcha";

export default function PageHome() {
  return (
    <div>
      PageHome
      <Captcha validate={(res) => {
        if (res) { alert("ok") }
        else { alert("error") }
      }}></Captcha>
      Enter the code and continue

      <button name="run" onClick={() => {
        myNotify("test", "success")
      }}>run</button>

      <h1 className="text-3xl font-bold underline">
        tailwind : Hello world!
      </h1>
    </div>
  );
}
