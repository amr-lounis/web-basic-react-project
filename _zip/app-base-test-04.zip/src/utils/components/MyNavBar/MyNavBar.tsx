export default function MyNavBar() {
  return (
    <>
      MyNavBar
      <br />---------------------------------------------<br />
    </>
  );
}