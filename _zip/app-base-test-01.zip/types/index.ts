//
declare module "*.module.css";
declare module "*.json";
//
declare module "*.png";
declare module "*.jpeg";
declare module "*.jpg";
declare module "*.svg";
//
