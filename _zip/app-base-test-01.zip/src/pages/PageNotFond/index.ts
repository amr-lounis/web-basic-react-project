import PageNotFond from "./PageNotFond";

export { PageNotFond };
