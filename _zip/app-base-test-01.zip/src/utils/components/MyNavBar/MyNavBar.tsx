export default function MyNavBar() {
  return (
    <>
    <line></line>
    Footer
    <line></line>
    </>
  );
}