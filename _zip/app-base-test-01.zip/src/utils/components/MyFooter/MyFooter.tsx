export default function Footer() {
  return (
    <>
      <line></line>
      Footer
      <line></line>
    </>
  );
}
