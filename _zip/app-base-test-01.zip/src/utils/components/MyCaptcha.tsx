import { Button, TextField } from "@mui/material";
import { useEffect } from "react";
import {
  loadCaptchaEnginge,
  validateCaptcha,
  LoadCanvasTemplateNoReload,
} from "react-simple-captcha";

export const MyCaptcha = ({ feedbackCap, size } : { feedbackCap:Function, size :number}) => {
  useEffect(() => {
    loadCaptchaEnginge(size, "#2E2E38", "white");
  });
  const doSubmit = () => {
    const user_captcha_input = (
      document.getElementById("user_captcha_input") as HTMLInputElement
    );

    if (validateCaptcha(user_captcha_input.value)) {
      feedbackCap(true)
    } else {
      feedbackCap(false)
    }
    user_captcha_input.value = "";
  };

  return (
    <div style={{ paddingTop: "2rem" }}>
      <div className="justify-content-center m-1">
        <Button
          type="submit"
          fullWidth
          variant="contained"
          onClick={doSubmit}
          onSubmit={() => {
            console.log("onSubmit")
          }}
        >
          Send
        </Button>
      </div>
      <div className="justify-content-center mt-4" >
        <div xs="6" style={{ textAlign: "center" }} onClick={() => {
          loadCaptchaEnginge(size, "#2E2E38", "white");
        }}>
          <LoadCanvasTemplateNoReload />
        </div>

      </div>
      <div className="justify-content-center"  >
        <div xs="6" >
          <TextField
            autoComplete="given-name"
            name="captcha"
            required
            fullWidth
            id="user_captcha_input"
            label="captcha"
            autoFocus
            variant="standard"
            inputProps={{ min: 0, style: { textAlign: 'center' } }}
          /></div>
      </div>
    </div >
  );
}
